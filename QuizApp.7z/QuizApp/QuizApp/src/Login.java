import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Login extends JFrame implements ActionListener {
    JButton rules, back;
    JTextField tfname, tfsection, tfcourse;
    JPanel contentPane;
    JLabel lblNewLabel, lblSection, lblNewLabel_2;
    private JLabel lblNewLabel_1;

    Login() {
        getContentPane().setBackground(Color.WHITE);
        getContentPane().setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/icon1.png"));
        
        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setIcon(new ImageIcon(Login.class.getResource("/icons/icon1.png")));
        lblNewLabel_1.setBounds(102, 39, 231, 270);
        getContentPane().add(lblNewLabel_1);

        JLabel heading = new JLabel("Coding Quiz Game");
        heading.setBounds(400, 23, 365, 45);
        heading.setFont(new Font("Mongolian Baiti", Font.BOLD, 40));
        heading.setForeground(Color.BLUE);
        getContentPane().add(heading);

        tfname = new JTextField();
        tfname.setBounds(470, 104, 195, 25);
        tfname.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        getContentPane().add(tfname);

        rules = new JButton("Start");
        rules.setFont(new Font("Tahoma", Font.BOLD, 11));
        rules.setBounds(443, 298, 120, 25);
        rules.setBackground(new Color(0, 0, 255));
        rules.setForeground(Color.white);
        rules.addActionListener(this);
        getContentPane().add(rules);

        back = new JButton("Back");
        back.setFont(new Font("Tahoma", Font.BOLD, 11));
        back.setBounds(585, 298, 120, 25);
        back.setBackground(new Color(0, 0, 255));
        back.setForeground(Color.white);
        back.addActionListener(this);
        getContentPane().add(back);

        setSize(821, 400);
        setLocationRelativeTo(null);
        
        // Remove these lines, as they are creating a new JPanel and its components
        // contentPane = new JPanel();
        // contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        // setContentPane(contentPane);
        // contentPane.setLayout(null);

        tfsection = new JTextField();
        tfsection.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        tfsection.setBounds(470, 157, 195, 25);
        getContentPane().add(tfsection);

        tfcourse = new JTextField();
        tfcourse.setForeground(new Color(0, 0, 0));
        tfcourse.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        tfcourse.setBounds(470, 210, 195, 25);
        getContentPane().add(tfcourse);

        JButton btnNewButton = new JButton("Register");
        btnNewButton.setForeground(new Color(255, 255, 255));
        btnNewButton.setBackground(new Color(0, 0, 255));
        btnNewButton.setAlignmentY(Component.BOTTOM_ALIGNMENT);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Connect();
            }
        });
        btnNewButton.setBounds(511, 246, 123, 37);
        getContentPane().add(btnNewButton);

        lblNewLabel = new JLabel("Name");
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblNewLabel.setBounds(470, 91, 46, 14);
        getContentPane().add(lblNewLabel);

        lblSection = new JLabel("Section");
        lblSection.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblSection.setBounds(470, 197, 46, 14);
        getContentPane().add(lblSection);

        lblNewLabel_2 = new JLabel("Course");
        lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblNewLabel_2.setBounds(470, 140, 46, 20);
        getContentPane().add(lblNewLabel_2);
    }

    protected void Connect() {
    	String name = tfname.getText();
        String section = tfsection.getText();
        String course = tfcourse.getText();
        
    	        Connection con = null;
    	        try {
    	            Class.forName("com.mysql.cj.jdbc.Driver");
    	            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javaquizgame_db", "root", "");
    	            PreparedStatement ps = con.prepareStatement("insert into user_info(name, course, section) values (?, ?, ?)");
    	            ps.setString(1, tfname.getText());
    	            ps.setString(2, tfcourse.getText());
    	            ps.setString(3, tfsection.getText());
    	            int x = ps.executeUpdate();
    	            if (x > 0) {
    	                JOptionPane.showMessageDialog(null, "Registered Successfully!");
    	            } else {
    	                JOptionPane.showMessageDialog(null, "Failed to Register!");
    	            }
    	        } catch (ClassNotFoundException | SQLException ex) {
    	            ex.printStackTrace();
    	        } finally {
    	            try {
    	                if (con != null) {
    	                    con.close();
    	                }
    	            } catch (SQLException e) {
    	                e.printStackTrace();
    	            }
    	        }
    	    }
  
  
    public static void main(String[] args) {
        new Login().setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == rules) {
            String name = tfname.getText();
            setVisible(false);
            new Rules(name);
        } else if (e.getSource() == back) {
            setVisible(false);
        }
    }
}
